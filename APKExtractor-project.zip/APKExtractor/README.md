# APK Extractor

Daftar aplikasi terpasang -> tombol **Simpan** (ke `Download/APK Extractor/`) atau **Bagikan**.

## Cara build
1. Buka folder ini di Android Studio (Ladybug 2024.2+ / JDK 17).
2. Tunggu Gradle sync (otomatis mengunduh Gradle 8.9 + dependensi).
3. Sambungkan HP (USB debugging) lalu klik Run, atau Build > Build APK(s).
   Via terminal: `gradle wrapper` sekali, lalu `./gradlew assembleDebug`.
   Hasil: `app/build/outputs/apk/debug/app-debug.apk`

## Catatan
- Aplikasi dengan split APK disimpan sebagai `.apks` (zip berisi base + split).
- `QUERY_ALL_PACKAGES` dibatasi Google Play; cocok untuk sideload/pemakaian pribadi.
- Android 10+ memakai MediaStore (tanpa izin penyimpanan); Android 9 ke bawah meminta izin tulis.
