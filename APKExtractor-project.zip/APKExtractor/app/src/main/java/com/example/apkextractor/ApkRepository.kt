package com.example.apkextractor

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class AppItem(
    val label: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val sourceDirs: List<String>,   // base APK + split APK (jika ada)
    val sizeBytes: Long,
    val isSystem: Boolean,
) {
    val isSplit: Boolean get() = sourceDirs.size > 1
}

object ApkRepository {

    private const val SUBFOLDER = "APK Extractor"
    private const val APK_MIME = "application/vnd.android.package-archive"

    @Suppress("DEPRECATION")
    suspend fun loadApps(context: Context): List<AppItem> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        pm.getInstalledPackages(0).mapNotNull { pi ->
            val ai = pi.applicationInfo ?: return@mapNotNull null
            val dirs = buildList {
                add(ai.sourceDir)
                ai.splitSourceDirs?.let { addAll(it) }
            }
            val flags = ai.flags
            val isSystem = (flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            AppItem(
                label = ai.loadLabel(pm).toString(),
                packageName = pi.packageName,
                versionName = pi.versionName ?: "-",
                versionCode = PackageInfoCompat.getLongVersionCode(pi),
                sourceDirs = dirs,
                sizeBytes = dirs.sumOf { File(it).length() },
                isSystem = isSystem,
            )
        }.sortedBy { it.label.lowercase() }
    }

    private fun fileNameFor(app: AppItem): String {
        val base = app.label.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_')
            .ifEmpty { app.packageName }
        val ext = if (app.isSplit) "apks" else "apk"
        return "${base}_${app.versionName}.$ext"
    }

    private fun mimeFor(app: AppItem) = if (app.isSplit) "application/zip" else APK_MIME

    /** Satu APK -> salin apa adanya. Banyak split -> dibungkus jadi .apks (zip). */
    private fun writeTo(app: AppItem, out: OutputStream) {
        if (!app.isSplit) {
            File(app.sourceDirs.first()).inputStream().use { it.copyTo(out) }
        } else {
            ZipOutputStream(out).use { zip ->
                app.sourceDirs.forEach { path ->
                    val f = File(path)
                    zip.putNextEntry(ZipEntry(f.name))
                    f.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
    }

    /** Simpan ke Download/APK Extractor. Mengembalikan jalur yang ramah dibaca. */
    suspend fun saveToDownloads(context: Context, app: AppItem): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val name = fileNameFor(app)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val resolver = context.contentResolver
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, mimeFor(app))
                        put(
                            MediaStore.Downloads.RELATIVE_PATH,
                            "${Environment.DIRECTORY_DOWNLOADS}/$SUBFOLDER"
                        )
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: error("Tidak bisa membuat berkas di Download")
                    try {
                        resolver.openOutputStream(uri)?.use { writeTo(app, it) }
                            ?: error("Tidak bisa menulis berkas")
                        values.clear()
                        values.put(MediaStore.Downloads.IS_PENDING, 0)
                        resolver.update(uri, values, null, null)
                    } catch (e: Exception) {
                        resolver.delete(uri, null, null)
                        throw e
                    }
                    "Download/$SUBFOLDER/$name"
                } else {
                    @Suppress("DEPRECATION")
                    val dir = File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                        SUBFOLDER
                    ).apply { mkdirs() }
                    val target = uniqueFile(dir, name)
                    FileOutputStream(target).use { writeTo(app, it) }
                    MediaScannerConnection.scanFile(context, arrayOf(target.path), null, null)
                    "Download/$SUBFOLDER/${target.name}"
                }
            }
        }

    /** Salin ke cache, lalu buat chooser "Bagikan" lewat FileProvider. */
    suspend fun prepareShare(context: Context, app: AppItem): Result<Intent> =
        withContext(Dispatchers.IO) {
            runCatching {
                val dir = File(context.cacheDir, "apks").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }   // bersihkan sisa berbagi sebelumnya
                val file = File(dir, fileNameFor(app))
                FileOutputStream(file).use { writeTo(app, it) }
                val uri = FileProvider.getUriForFile(
                    context, "${context.packageName}.fileprovider", file
                )
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = mimeFor(app)
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                Intent.createChooser(send, "Bagikan ${app.label}")
            }
        }

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (f.exists()) {
            f = File(dir, "$stem ($i)$ext")
            i++
        }
        return f
    }
}

object IconCache {
    private val cache = LruCache<String, ImageBitmap>(150)

    suspend fun get(context: Context, packageName: String): ImageBitmap? {
        cache.get(packageName)?.let { return it }
        return withContext(Dispatchers.Default) {
            runCatching {
                context.packageManager.getApplicationIcon(packageName)
                    .toBitmap(96, 96).asImageBitmap()
            }.getOrNull()?.also { cache.put(packageName, it) }
        }
    }
}
